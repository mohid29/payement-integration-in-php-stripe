<?php
require_once('vendor/autoload.php');
\Stripe\Stripe::setApiKey('sk_test_EXmjM5Fo2euWqECpqMi1xr1C0095u604LE');
$token = $_POST['stripeToken'];
// This is a $20.00 charge in US Dollar.
$charge = \Stripe\Charge::create(
    array(
        'amount' => 200000,
        'currency' => 'usd',
        'source' => $token
    )
);
print_r($charge);