<?php 
// Product Details 
// Minimum amount is $0.50 US 
$itemName = "Demo Product"; 
$itemNumber = "PN12345"; 
$itemPrice = 100.00; 
$currency = "USD"; 
 
// Stripe API configuration  
define('STRIPE_API_KEY', 'sk_test_EXmjM5Fo2euWqECpqMi1xr1C0095u604LE'); 
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_kiCWsC3rhdEFdJOHhcUaYfDo00kt2t8Zea'); 
  
// Database configuration  
define('DB_HOST', 'localhost'); 
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', ''); 
define('DB_NAME', 'orders');

?>